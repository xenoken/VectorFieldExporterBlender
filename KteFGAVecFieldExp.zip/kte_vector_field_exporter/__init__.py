## Vector Field Exporter
## Author : Kennedy Tochukwu Ekeoha (mailto:ekeohak@gmail.com)
## License : MIT License
##
##The MIT License (MIT)
##
##Copyright (c) 2016 Kennedy Tochukwu Ekeoha
##
##Permission is hereby granted, free of charge, to any person obtaining a copy
##of this software and associated documentation files (the "Software"), to deal
##in the Software without restriction, including without limitation the rights
##to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
##copies of the Software, and to permit persons to whom the Software is
##furnished to do so, subject to the following conditions:
##
##The above copyright notice and this permission notice shall be included in all
##copies or substantial portions of the Software.
##
##THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
##IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
##FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
##AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
##LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
##OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
##SOFTWARE.
bl_info = {
    "name": "Vector Field Exporter (.FGA)",
    "author": "Kennedy Tochukwu Ekeoha",
    "version": (0, 5),
    "blender": (2, 75, 0),
    "location": "Properties > Scene",
    "description": "Create and Export a Vector Field in the .FGA format",
    "warning": "",
    "wiki_url": "",
    "category": "Import-Export",
    }


import bpy
from bpy import types,data,context,ops
from . import exporter


class KTEVFEGenerator(bpy.types.Operator):
    """Generate a Vector Field"""
    
    bl_idname = "kte.vf_generator"
    bl_label = "Create Vector Field"
        
    @classmethod
    def poll(cls, context):
        return True
    
    def execute(self,context):
        #create vector field For this we are using a simple cube. This is what the target engine recognizes.
        bpy.ops.mesh.primitive_cube_add()   
        #add a particle system to the vector field.
        bpy.ops.object.particle_system_add()
        #get handle to the vector field object
        vf = context.scene.objects.active
        #change vector field name
        vf.name = "VectorField_001"
        #get handle to the newly created particle system
        ps = vf.particle_systems[0] # I assume it is the first in the list.
        # to prevent accidental deletion we make the cube unselectable temporarily
        vf.hide_select = True
        #apply a bounds display to better see the particles
        vf.draw_type = 'BOUNDS'
        #change some settings for the particle system to some defaults. The user is still able to edit these properties.
        setts = ps.settings
        setts.grid_resolution = 16
        setts.distribution = 'GRID'
        setts.frame_start = 0
        setts.frame_end = 1
        setts.lifetime = 10
        setts.show_velocity = True
        setts.emit_from='VOLUME'
        #deselect everything, especially the vector field
        bpy.ops.object.select_all(action='DESELECT')
        #go to frame 1
        context.scene.frame_current = 1
        #rescale the object
        vf.scale.x =3
        vf.scale.y = vf.scale.x
        vf.scale.z = vf.scale.x
        return {'FINISHED'}

class KTEVFEExporter(bpy.types.Operator):
    """Export the selected Vector Field"""
    bl_idname = "kte.vf_exporter"
    bl_label = "Export Vector Field"
    filepath= bpy.props.StringProperty(subtype="FILE_PATH")
    @classmethod
    def poll(self,context):
        return context.object is not None
    def execute(self,context):
        prev_frame = context.scene.frame_current
        context.scene.frame_current = 1
        _filepath = self.filepath + ".fga"
        #export logic
        exporter.export(context.object,_filepath)
        #return the animation to the start.
        context.scene.frame_current=prev_frame
        return {'FINISHED'}
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class KTEVFEPanel(bpy.types.Panel):
    """Creates a Panel in the scene context of the properties editor"""
    bl_label = "Vector Field Exporter"
    bl_idname = "kte.vf_panel"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"
    
    #bpy.types.WindowManager.kte.export_dir_path = bpy.props.StringProperty(name="ExportDirPath")
    def draw(self, context):
        layout = self.layout
        #layout.box().row().label("Vector Field Exporter")
        layout.row().prop_search(context.scene.objects,"active",bpy.data,"objects",text="Vector Field Domain")
        #row = layout.row()
        #row.scale_y = 2.0
        #row.enabled = True
        #row.operator("kte.vf_exporter",text="Export VF")

def register():
    bpy.utils.register_class(KTEVFEGenerator)
    bpy.utils.register_class(KTEVFEExporter)    
    bpy.utils.register_class(KTEVFEPanel)

def unregister():
    bpy.utils.unregister_class(KTEVFEPanel)
    bpy.utils.unregister_class(KTEVFEExporter)
    bpy.utils.unregister_class(KTEVFEGenerator)

if __name__ == "__main__":
    register()
